/* Trivia Game Server 
Joseph Gargiulo
I pledge my honor that I have abided by the Stevens Honor System
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h> 

#define DEFAULT_FILE "questions.txt"
#define DEFAULT_IP "127.0.0.1"
#define DEFAULT_PORT 25555
#define MAX_CONNECTIONS 3

#define YELLOW "\x1B[38;5;227m" /* this will be the color for the questions*/
#define PURPLE "\e[0;35m" /* this will be for errors */
#define BLUE "\x1B[1;34m" /* for when the game starts */
#define GREEN "\x1B[32m" /* font for the winning messages */
#define DEFAULT "\x1b[0m"

struct Entry {
    char prompt[1024];
    char options[3][50];
    int answer_idx;
};

struct Player {
    int fd;
    int score;
    char name[128];
};

void print_usage(char *prog) {
    printf("Usage: %s [-f question_file] [-i IP_address] [-p port_number] [-h]\n\n", prog);
    printf(" -f question_file       Default to \"question.txt\";\n");
    printf(" -i IP_address          Default to \"127.0.0.1\";\n");
    printf(" -p port_number         Default to 25555;\n");
    printf(" -h                     Display this help info.\n");
}

int read_questions(struct Entry* arr, char* filename) {
    int count = 0;
    FILE* fp = fopen(filename, "r");

    if (!fp) {
        fprintf(stderr, "%sError: Failed to open file.\n", PURPLE);
        exit(EXIT_FAILURE);
    }

    char line[1024];

    while (fgets(line, sizeof(line), fp) != NULL) {
        /* Skip any empty lines */ 
        if (strcmp(line, "\n") == 0) continue;

        /* Copy the question prompt */ 
        strcpy(arr[count].prompt, line);

        /* Read the options line */ 
        if (fgets(line, sizeof(line), fp) == NULL) break;
        sscanf(line, "%s %s %s", arr[count].options[0], arr[count].options[1], arr[count].options[2]);

        /* Read the correct answer */
        if (fgets(line, sizeof(line), fp) == NULL) break;
        line[strcspn(line, "\n")] = '\0';

        /* Find the index of the correct answer */
        for (int i = 0; i < 3; i++) {
            if (strcmp(arr[count].options[i], line) == 0) {
                arr[count].answer_idx = i;
                break;
            }
        }

        /* Increment question count */
        count++;

        /* Too many questions*/
        if (count >= 50) break;
    }

    fclose(fp);
    return count; 
}

int main(int argc, char *argv[]) {
    char *question_file = DEFAULT_FILE;
    char *ip_address = DEFAULT_IP;
    int port_number = DEFAULT_PORT;
    int opt;

    // Argument parsing
    if (argc > 1 && argv[1][0] != '-') {
        fprintf(stderr,"%sUnknown option '%s' received. %s\n", PURPLE,argv[1],DEFAULT);
        exit(EXIT_FAILURE);
    }

    opterr = 0;
    while ((opt = getopt(argc, argv, "hf:i:p:")) != -1) {
        switch (opt) {
            case 'h':
                print_usage(argv[0]);
                return EXIT_SUCCESS;
            case 'f':
                question_file = optarg;
                break;
            case 'i':
                ip_address = optarg;
                break;
            case 'p':
                port_number = atoi(optarg);
                break;
            case '?':
                if (isprint(optopt)) {
                    fprintf(stderr, "%sError: Unknown option '-%c' received%s.\n", PURPLE, optopt, DEFAULT);
                } else {
                    fprintf(stderr, "%sError: Unknown option received%s.\n", PURPLE, DEFAULT);
                }
                exit(EXIT_FAILURE);

        }
    }

    // Socket setup
    int server_fd, client_fd;
    struct sockaddr_in server_addr, in_addr;
    socklen_t addrlen = sizeof(in_addr);

    if((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0){
        perror("Error Creating Socket");
        exit(EXIT_FAILURE);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_number);

    if (inet_pton(AF_INET, ip_address, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        exit(EXIT_FAILURE);
    }

    if(bind(server_fd, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0){
        perror("Error binding");
        exit(EXIT_FAILURE);
    }
    
    if(listen(server_fd, MAX_CONNECTIONS) < 0){
        perror("Listening error");
        exit(EXIT_FAILURE);
    }

    printf("%s+------------------------+\n", YELLOW);
    printf("%s| Welcome to 392 Trivia! |\n", YELLOW);
    printf("%s+------------------------+%s\n", YELLOW, DEFAULT);

    // Read questions database
    struct Entry questions[50];
    int quesNum = read_questions(questions, question_file);
    if (quesNum < 0) {
        fprintf(stderr, "%sFailed to read questions from the file%s\n",PURPLE, DEFAULT);
        exit(EXIT_FAILURE);
    }

    // Accept connections
    fd_set myset;
    FD_ZERO(&myset);
    FD_SET(server_fd,&myset);
    struct Player players[MAX_CONNECTIONS];
    int player_count = 0;
    int game_started = 0;

    for(int i = 0; i < MAX_CONNECTIONS; i++) {
        players[i].fd = -1;
        strcpy(players[i].name, "null");
        players[i].score = 0;
    }

    char buffer[1024];
    char* get_name = "Please type your name:\n";

    while(1) {
        if (game_started) {
            break;
        }

        FD_SET(server_fd,&myset);
        int max_fd = server_fd;

        for(int i = 0; i < MAX_CONNECTIONS; i++){
            if(players[i].fd != -1 ){ 
                FD_SET(players[i].fd,&myset);
                if(players[i].fd > max_fd) max_fd = players[i].fd;
            }
        }

        select(max_fd + 1, &myset, NULL, NULL, NULL);

        if(FD_ISSET(server_fd, &myset)){
            client_fd = accept(server_fd, (struct sockaddr*)&in_addr, &addrlen);
            if(player_count < MAX_CONNECTIONS){
                printf("%sNew connection detected!%s\n", GREEN, DEFAULT);
                player_count++;
                for(int i = 0; i < MAX_CONNECTIONS; i++){
                    if(players[i].fd == -1){
                        players[i].fd = client_fd;
                        write(players[i].fd, get_name, strlen(get_name));
                        break;
                    } 
                }
            }else{
                printf("%sMax connections reached!%s\n", PURPLE, DEFAULT);
                close(client_fd);
            }
        }

        for(int i = 0; i < MAX_CONNECTIONS; i++){
            if(players[i].fd != -1 && FD_ISSET(players[i].fd, &myset)){
                int recvbytes = read(players[i].fd, buffer, sizeof(buffer));
                if(recvbytes == 0){
                    printf("%sConnection lost!%s\n",PURPLE,DEFAULT);
                    close(players[i].fd);
                    players[i].fd = -1;
                    player_count--;

                    int active_players = 0;
                    int remaining_player = 0;
                    for (int j = 0; j < MAX_CONNECTIONS; j++) {
                        if (players[j].fd != -1) {
                            active_players++;
                            remaining_player = j;
                        }
                    }

                    if(active_players == 1){
                        printf("%s%s Wins by forfeit!%s\n\n",GREEN, players[remaining_player].name,DEFAULT);
                        close(players[remaining_player].fd);
                        game_started = 1;
                    } else if(active_players == 0){
                        printf("%sGame ended, no more players playing, this is so sad :(%s\n\n", PURPLE, DEFAULT);
                        game_started = 1;
                    }
                } else {
                    buffer[recvbytes] = '\0';
                    printf("Hi %s!\n", buffer);
                    strcpy(players[i].name, buffer);
                }
            }
        }

        int flag = 1;
        for (int i = 0; i < MAX_CONNECTIONS; i++) {
            if (strcmp(players[i].name, "null") == 0) {
                flag = 0;
                break;
            }
        }
        if (player_count == MAX_CONNECTIONS && flag == 1 ){
            printf("%s  THE GAME STARTS NOW! LETS GOOOO%s\n\n", BLUE, DEFAULT);
            game_started = 1;
        } 
    } 

    // Print relevant messages only if at least one player has connected and the game hasn't started yet
    if (player_count > 0 && !game_started) {
        printf("Game ended. Waiting for more players to join...\n");
    }

    // Game logic loop
    int question_index = 0;

    while (question_index < quesNum && player_count > 0) {
        // Check if the game has started and there are active players
        if (game_started && player_count > 0) {
            // Print questions only if there are active players
            printf("%sQuestion %d: %s%s\n", YELLOW, question_index + 1, questions[question_index].prompt, DEFAULT);
            printf("1: %s\n2: %s\n3: %s\n\n", questions[question_index].options[0], 
                                                questions[question_index].options[1], 
                                                questions[question_index].options[2]);

            // Prepare the question and options strings
            char question_string[2048];
            sprintf(question_string, "%sQuestion %d: %s%s\n", YELLOW, question_index + 1, questions[question_index].prompt, DEFAULT);
            char options_string[2048];
            sprintf(options_string, "1: %s\n2: %s\n3: %s\n\n", questions[question_index].options[0], 
                                                                questions[question_index].options[1], 
                                                                questions[question_index].options[2]);

            // Broadcast the question and options to all active players
            for (int i = 0; i < MAX_CONNECTIONS; i++) {
                if (players[i].fd != -1) {
                    write(players[i].fd, question_string, strlen(question_string));
                    write(players[i].fd, options_string, strlen(options_string));
                }
            }
        }

        // Wait for player responses
        fd_set read_fds;
        FD_ZERO(&read_fds);
        int max_fd = 0;

        for (int i = 0; i < MAX_CONNECTIONS; i++) {
            if (players[i].fd != -1) {
                FD_SET(players[i].fd, &read_fds);
                if (players[i].fd > max_fd) {
                    max_fd = players[i].fd;
                }
            }
        }

        select(max_fd + 1, &read_fds, NULL, NULL, NULL);

        // Process player responses
        int correct_answer_sent = 0; // Variable to track if correct answer message has been sent

        for (int i = 0; i < MAX_CONNECTIONS; i++) {
            if (players[i].fd != -1 && FD_ISSET(players[i].fd, &read_fds)) {
                char answer[1024];
                int ans_bytes = read(players[i].fd, answer, sizeof(answer));

                if (ans_bytes == 0) {
                    // Handle connection lost
                    printf("%sConnection lost!%s\n", PURPLE, DEFAULT);
                    close(players[i].fd);
                    players[i].fd = -1;
                    player_count--;

                    // Check if there's only one player left
                    if (player_count == 1) {
                        int remaining_player = -1;
                        for (int j = 0; j < MAX_CONNECTIONS; j++) {
                            if (players[j].fd != -1) {
                                remaining_player = j;
                                break;
                            }
                        }
                        printf("%s%s Wins by forfeit!%s\n\n", GREEN, players[remaining_player].name, DEFAULT);
                        close(players[remaining_player].fd);
                        game_started = 0; // End the game
                    }
                } else {
                    answer[ans_bytes] = '\0';
                    int chosen_answer = atoi(answer);

                    // Check if the answer is correct
                    if (chosen_answer == questions[question_index].answer_idx + 1) {
                        players[i].score++;
                        if (!correct_answer_sent) {
                            printf("%sCorrect answer!%s\n", GREEN, DEFAULT);
                            correct_answer_sent = 1;
                        }
                    } else {
                        printf("%sIncorrect answer!%s\n", PURPLE, DEFAULT);
                    }
                }
            }
        }

        // Move to the next question
        question_index++;
        sleep(2); // Add some delay before moving to the next question
    }

    // Display final scores
    printf("\n%sFinal Scores:\n", YELLOW);
    for (int i = 0; i < MAX_CONNECTIONS; i++) {
        if (players[i].fd != -1) {
            printf("%s: %d\n", players[i].name, players[i].score);
        }
    }
    printf("%sGame ended. Exiting server.%s\n", PURPLE, DEFAULT);

    // Close all connections
    for (int i = 0; i < MAX_CONNECTIONS; i++) {
        if (players[i].fd != -1) {
            close(players[i].fd);
        }
    }

    close(server_fd);
    return EXIT_SUCCESS;
}
