/*
The client 
Joseph Gargiulo
I pledge my honor that I have abided by the Stevens Honor System
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>

#define PURPLE "\e[0;35m" /* this will be for errors */
#define DEFAULT "\x1b[0m"
#define YELLOW "\x1B[38;5;227m"

#define DEFAULT_IP "127.0.0.1"
#define DEFAULT_PORT 25555

void print_usage(char *prog) {
    printf("Usage: %s [-i IP_address] [-p port_number] [-h]\n", prog);
    printf(" -i IP_address          Default to \"127.0.0.1\";\n");
    printf(" -p port_number         Default to 25555;\n");
    printf(" -h                     Display this help info.\n");
}

void setup_connection(int argc, char** argv, int* server_fd) {
    int opt;
    char *ip_address = DEFAULT_IP;
    int port_number = DEFAULT_PORT;

    if (argc > 1 && argv[1][0] != '-') {
        fprintf(stderr,"%sUnknown option '%s' received. %s\n", PURPLE,argv[1],DEFAULT);
        exit(EXIT_FAILURE);
    }

    opterr = 0;
    while ((opt = getopt(argc, argv, "hi:p:")) != -1) {
        switch (opt) {
            case 'h':
                print_usage(argv[0]);
                exit(EXIT_SUCCESS);
            case 'i':
                ip_address = optarg;
                break;
            case 'p':
                port_number = atoi(optarg);
                break;
            case '?':
                if (optopt == 'i' || optopt == 'p') {
                    fprintf(stderr, "%sError: Option '-%c' requires an argument.%s\n", PURPLE, optopt, DEFAULT);
                } else {
                    fprintf(stderr, "%sError: Unknown option '-%c' received%s.\n", PURPLE, optopt, DEFAULT);
                }
                exit(EXIT_FAILURE);
        }
    }

    struct sockaddr_in server_addr;

    if((*server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0){
        perror("Error Creating Socket");
        exit(1);
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port_number);

    if (inet_pton(AF_INET, ip_address, &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        exit(1);
    }

    if (connect(*server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection Failed");
        exit(1);
    }
}

void enter_game(int server_fd) {
    fd_set read_fds;
    char buffer[1024];
    int max_fd = server_fd > STDIN_FILENO ? server_fd : STDIN_FILENO;

    while(1) {
        FD_ZERO(&read_fds);
        FD_SET(STDIN_FILENO, &read_fds);
        FD_SET(server_fd, &read_fds);

        if (select(max_fd + 1, &read_fds, NULL, NULL, NULL) == -1) {
            perror("Error in select");
            exit(EXIT_FAILURE);
        }

        if (FD_ISSET(STDIN_FILENO, &read_fds)) {
            scanf("%s", buffer);
            send(server_fd, buffer, strlen(buffer), 0);
        }

        if (FD_ISSET(server_fd, &read_fds)) {
            int recvbytes = recv(server_fd, buffer, sizeof(buffer), 0);
            if (recvbytes <= 0) {
                printf("Server closed the connection. Exiting...\n");
                break;
            } else {
                buffer[recvbytes] = '\0';
                printf("%s%s%s", YELLOW, buffer, DEFAULT);
            }
        }
    }
}

int main(int argc, char *argv[]) {
    int server_fd;
    setup_connection(argc, argv, &server_fd);
    enter_game(server_fd);
    close(server_fd);
    return 0;
}
